package com.vianax.painel;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,6,17), CARD = Color.rgb(25,17,39), PURPLE = Color.rgb(192,132,252);
    private SharedPreferences prefs;
    private LinearLayout root;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("vianax", MODE_PRIVATE);
        build();
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,28); root.setBackgroundColor(BG);
        scroll.addView(root); setContentView(scroll);
        TextView title = text("VIANAX PAINEL", 28, PURPLE, true); title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView sub = text("FREE FIRE • CENTRAL DE CONFIGURAÇÕES", 12, Color.LTGRAY, true); sub.setGravity(Gravity.CENTER);
        root.addView(sub); space(18);
        addCard("SENSIBILIDADE", "Ajuste os valores e salve seu perfil.");
        addSlider("Geral", 0, 200, 95);
        addSlider("Ponto vermelho", 0, 200, 90);
        addSlider("Mira 2x", 0, 200, 85);
        addSlider("Mira 4x", 0, 200, 80);
        addSlider("Mira AWM", 0, 200, 35);
        addSlider("Olhadinha", 0, 200, 70);
        addCard("HUD", "Ajustes pessoais para consultar e reproduzir dentro das configurações do jogo.");
        addSlider("Tamanho do botão de tiro (%)", 1, 100, 50);
        addSlider("Opacidade do HUD (%)", 1, 100, 85);
        addCard("PERFIL DE JOGO", "Escolha um perfil de referência.");
        String[] profiles = {"Equilibrado", "Precisão", "Movimento"};
        Spinner spinner = new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, profiles));
        int selected = prefs.getInt("profile", 0); spinner.setSelection(selected);
        root.addView(spinner);
        Button save = button("SALVAR CONFIGURAÇÕES");
        save.setOnClickListener(v -> { prefs.edit().putInt("profile", spinner.getSelectedItemPosition()).apply(); Toast.makeText(this,"Configurações salvas neste aparelho!",Toast.LENGTH_SHORT).show(); });
        root.addView(save);
        Button reset = button("RESTAURAR PADRÕES");
        reset.setOnClickListener(v -> { prefs.edit().clear().apply(); Toast.makeText(this,"Padrões restaurados. Reabra o painel.",Toast.LENGTH_SHORT).show(); });
        root.addView(reset);
        space(12);
        TextView note = text("Aviso: este painel salva sugestões no aparelho. Ele não modifica o Free Fire, não injeta arquivos e não controla a mira dentro do jogo. Use os valores manualmente nas configurações do jogo.", 12, Color.LTGRAY, false);
        root.addView(note);
    }
    private void addCard(String heading, String desc) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(16,14,16,14);
        box.setBackground(shape(CARD,18)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=18; root.addView(box,p);
        box.addView(text(heading,17,PURPLE,true)); box.addView(text(desc,12,Color.LTGRAY,false));
    }
    private void addSlider(String label, int min, int max, int def) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(1); box.setPadding(8,10,8,4);
        TextView name = text(label + " • " + prefs.getInt(label, def), 14, Color.WHITE, true); box.addView(name);
        SeekBar seek = new SeekBar(this); seek.setMax(max-min); seek.setProgress(prefs.getInt(label,def)-min);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(PURPLE));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b,int value,boolean user) { name.setText(label + " • " + (value+min)); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) { prefs.edit().putInt(label,b.getProgress()+min).apply(); }
        });
        box.addView(seek); root.addView(box);
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackground(shape(Color.rgb(112,48,160),16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=12; root.addView(b,p); return b;
    }
    private void space(int h) { View v = new View(this); root.addView(v,new LinearLayout.LayoutParams(1,h)); }
}
