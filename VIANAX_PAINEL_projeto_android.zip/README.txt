VIANAX PAINEL — projeto Android

O que funciona:
- Controles deslizantes de sensibilidade e HUD.
- Salvamento local das configurações no aparelho.
- Perfis de referência e restauração dos padrões.
- Interface roxo neon/preto.

Limite importante:
Este aplicativo é um painel auxiliar. Ele NÃO se conecta ao Free Fire, não altera arquivos do jogo, não injeta código e não oferece mira automática. Os valores devem ser aplicados manualmente nas configurações do jogo.

Como gerar o APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta VIANAX_PAINEL no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Se solicitado, instale o Android SDK 35.
5. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/app-debug.apk.

Este ambiente entregou o projeto-fonte compactado; não gerou nem assinou um APK instalável.
